export { default as UploadIllustration } from './upload-illustration';
export { default as ForbiddenIllustration } from './forbidden-illustration';
export { default as SeverErrorIllustration } from './sever-error-illustration';
export { default as ComingSoonIllustration } from './coming-soon-illustration';
export { default as MaintenanceIllustration } from './maintenance-illustration';
export { default as PageNotFoundIllustration } from './page-not-found-illustration';
