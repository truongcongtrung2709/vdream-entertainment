'use client';

import { createContext } from 'react';

import { ContextType } from '../types';

// ----------------------------------------------------------------------

export const AuthContext = createContext({} as ContextType);
