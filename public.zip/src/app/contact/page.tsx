import ContactView from 'src/sections/_contact/view/contact-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Dream: Đối Tác',
};

export default function ContactPage() {
  return <ContactView />;
}
