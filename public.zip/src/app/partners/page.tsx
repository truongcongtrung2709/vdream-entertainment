import CollaborationView from 'src/sections/_collaboration/view/collaboration-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Dream: Đối Tác',
};

export default function CollaborationPage() {
  return <CollaborationView />;
}
