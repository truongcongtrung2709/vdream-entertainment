import { View403 } from 'src/sections/error';

// ----------------------------------------------------------------------

export const metadata = {
  title: '403 Forbidden',
};

export default function Page403() {
  return <View403 />;
}
