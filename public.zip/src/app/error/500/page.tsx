import { View500 } from 'src/sections/error';

// ----------------------------------------------------------------------

export const metadata = {
  title: '500 Internal Server Error',
};

export default function Page500() {
  return <View500 />;
}
