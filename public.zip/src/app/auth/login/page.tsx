import LoginView from 'src/sections/auth/login/login-view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Vdream: Login',
};

export default function LoginPage() {
  return <LoginView />;
}
