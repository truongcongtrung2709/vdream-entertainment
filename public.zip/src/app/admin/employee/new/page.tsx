

// ----------------------------------------------------------------------

import { EmployeeCreateView } from "src/sections/dashboard/employee/view";

export const metadata = {
  title: 'Dashboard: Create a new user',
};

export default function UserCreatePage() {
  return <EmployeeCreateView />;
}
