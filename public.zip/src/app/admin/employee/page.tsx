import { EmployeeListView } from "src/sections/dashboard/employee/view";

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Dashboard: User Profile',
};

export default function UserProfilePage() {
  return <EmployeeListView />;
}
