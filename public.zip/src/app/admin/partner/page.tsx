import { CollaboratorListView } from "src/sections/dashboard/collaborator/view";

// ----------------------------------------------------------------------


export const metadata = {
  title: 'Dashboard: Partner List',
};

export default function CollaboratorPage() {
  return <CollaboratorListView />;
}
