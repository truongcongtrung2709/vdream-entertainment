
// ----------------------------------------------------------------------

import { CollaboratorCreateView } from "src/sections/dashboard/collaborator/view";

export const metadata = {
  title: 'Dashboard: Create a new collaborator',
};

export default function UserCreatePage() {
  return <CollaboratorCreateView />;
}
