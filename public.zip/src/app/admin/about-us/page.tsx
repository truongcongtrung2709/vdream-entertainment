import { AboutUsView } from 'src/sections/about-us/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Dashboard: About',
};

export default function OverviewAppPage() {
  return <AboutUsView />;
}
