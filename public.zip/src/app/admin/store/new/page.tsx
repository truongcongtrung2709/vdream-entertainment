
import { StoreCreateView } from "src/sections/dashboard/store/view";

// ----------------------------------------------------------------------


export const metadata = {
  title: 'Dashboard: Create a new product',
};

export default function UserCreatePage() {
  return <StoreCreateView />;
}
