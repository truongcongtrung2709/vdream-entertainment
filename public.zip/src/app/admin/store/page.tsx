import { StoreListView } from "src/sections/dashboard/store/view";

// ----------------------------------------------------------------------


export const metadata = {
  title: 'Dashboard: User Profile',
};

export default function UserProfilePage() {
  return <StoreListView />;
}
