import { IntroductionView } from "src/sections/dashboard/introduction/view";

// ----------------------------------------------------------------------


export const metadata = {
  title: 'Dashboard: VDream',
};

export default function HomePage() {
  return <IntroductionView />;
}
