// ----------------------------------------------------------------------

import StoreView from "src/sections/_store/view/store-view";


export const metadata = {
  title: 'Dream: Sản phẩm',
};

export default function Collaboration() {
  return <StoreView />;
}
