import { IconifyIcon } from '@iconify/react';

// ----------------------------------------------------------------------

export type IconifyProps = IconifyIcon | string;
